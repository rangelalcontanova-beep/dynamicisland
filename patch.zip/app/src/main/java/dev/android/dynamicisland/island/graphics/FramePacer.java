package dev.android.dynamicisland.island.graphics;

/**
 * A per-surface render budget. Time remains real elapsed time; skipped frames never slow down clocks or springs.
 *
 * <p>Ambient motion (music waveform, album glow, media effects: nothing the user is touching) is always capped at
 * {@link #CONTINUOUS_NS} (30 fps), even when low-performance mode is off. Before, it ran at the full refresh rate
 * of the display (90/120 Hz) for as long as music played, which was the main source of CPU/GPU wake-ups and
 * battery drain. Direct manipulation and structural transitions stay uncapped (or 60 fps in low-performance mode).
 */
public final class FramePacer {
    private static final long INTERACTIVE_NS = 1_000_000_000L / 60;
    private static final long CONTINUOUS_NS = 1_000_000_000L / 30;
    /** Vsync timestamps can differ by a few microseconds between refresh cycles. */
    private static final long TOLERANCE_NS = 100_000;
    private long lastRendered;

    public boolean allow(boolean limited, boolean interactive, long frameNanos) {
        long interval = interval(limited, interactive);
        if (lastRendered != 0 && frameNanos >= lastRendered && frameNanos - lastRendered + TOLERANCE_NS < interval) return false;
        lastRendered = frameNanos;
        return true;
    }

    /** Delay before requesting vsync. Floor rounding lets the display choose the next suitable frame. */
    public long delayMillis(boolean limited, boolean interactive, long nowNanos) {
        if (lastRendered == 0 || nowNanos < lastRendered) return 0;
        return Math.max(0, interval(limited, interactive) - (nowNanos - lastRendered)) / 1_000_000;
    }

    /** Records a frame drawn outside {@link #allow} (for example by a view invalidated for another reason). */
    public void mark(long frameNanos) { lastRendered = frameNanos; }

    public void reset() { lastRendered = 0; }

    private static long interval(boolean limited, boolean interactive) {
        if (interactive) return limited ? INTERACTIVE_NS : 0;
        return CONTINUOUS_NS;
    }
}
